#define INST_R(x) cout << "Read from " << hex << &(x) << endl
#define INST_W(x) cout << "Write to " << hex << &(x) << endl
void *_inst_p;
